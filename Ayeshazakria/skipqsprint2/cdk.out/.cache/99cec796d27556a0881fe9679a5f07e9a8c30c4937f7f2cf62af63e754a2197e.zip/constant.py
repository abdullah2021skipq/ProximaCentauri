URL_TO_MONITOR= "www.skipq.org"
URL_MONITOR_NAMESPACE="ayesha_skipq_webhealth"
URL_MONITOR_NAME_AVAILABILITY="url_availability"
URL_MONITOR_NAME_LATENCY="url_latency"